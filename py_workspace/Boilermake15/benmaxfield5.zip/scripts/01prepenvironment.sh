sudo yum install libxml2-devel libxslt-devel python-devel gcc
easy_install pip
sudo pip install lxml
